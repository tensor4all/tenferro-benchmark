#include <valgrind/callgrind.h>

int under_valgrind(void) { return RUNNING_ON_VALGRIND; }
void profile_start(void) {
    CALLGRIND_START_INSTRUMENTATION;
    CALLGRIND_ZERO_STATS;
}
void profile_stop(void) {
    CALLGRIND_DUMP_STATS;
    CALLGRIND_STOP_INSTRUMENTATION;
}
