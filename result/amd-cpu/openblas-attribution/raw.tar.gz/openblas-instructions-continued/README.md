# Follow-up instruction artifacts

Run commands **inside** `tenferro-openblas-analysis`, from the benchmark worktree
root. These are instruction profiles, NOT native benchmark timings. The image,
pins, prior Rust profiles and lockfile are recorded in the sibling
`openblas-instructions` directory. No production kernel code was changed.

## Setup-excluding PyTorch window

The initial whole-process `mul-pytorch-n1` includes imports/setup (~5.2B Ir).
It is NOT used in the paired comparisons. `profile_pytorch.py` instead reuses
the benchmark's format/path/thread helpers, reproduces its float64-zero
opt_einsum expression, and profiles only warmed execution/output cleanup.

```bash
source scripts/thread_env.sh
configure_cpu_thread_env 1
export PYTHONHASHSEED=0
helpers=data/results/amd-cpu/diagnostics/openblas-instructions-continued
out="$helpers/reproduction-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$out"
cp "$helpers/profile_pytorch.py" "$out/"
cc -O2 -shared -fPIC "$helpers/callgrind_window.c" -o "$out/callgrind_window.so"
# CASE / COUNT / STRATEGY vary according to the list below.
CASE=bin_elementwise_mul_2048x2048 COUNT=1 STRATEGY=opt_flops
timeout --kill-after=10s 240s valgrind --tool=callgrind --instr-atstart=no \
  --callgrind-out-file="$out/profile.callgrind" \
  .venv/bin/python "$out/profile_pytorch.py" "$CASE" "$COUNT" "$STRATEGY" \
  > "$out/profile.log" 2>&1
callgrind_annotate --auto=no --threshold=100 "$out/profile.callgrind.1"
```

Use a different output filename for each run. The **`.1` client-request dump**
is the measured window. The plain filename is the tiny exit dump after
instrumentation has stopped. The printed whole-process `Collected` count
includes a few marker instructions that are absent from the `.1` window;
all result tables use the annotated window count.

Recorded windows:

- `bin_elementwise_mul_2048x2048`: counts 1 and 3, opt_flops.
- `bin_batched_matmul_b32_m128_n128_k128`: counts 1 and 3, opt_flops.
- `bin_matmul_1024`: count 1, opt_flops.
- `lm_batch_likelihood_sentence_3_12d`: count 1 for each of opt_flops and opt_size.

## Rust differential profiles

Use the existing optimized debug-info binary, `BENCH_WARMUPS=1`, explicit
1T environment, and a whole-process Callgrind profile. Setup cancels from
N=3 minus N=1 (apart from allocator/harness-state effects). Do not use
caller-thread-only toggle collection: it can omit Rayon worker execution.

```bash
BENCH_INSTANCE=lm_batch_likelihood_sentence_3_12d BENCH_RUNS=3 \
BENCH_WARMUPS=1 TENFERRO_ANALYZE_PATH=1 TENFERRO_MODE=trace \
  timeout --kill-after=10s 240s valgrind --tool=callgrind \
  --callgrind-out-file="$out/rust.callgrind" \
  target/release/tenferro-einsum-benchmark > "$out/rust.log" 2>&1
callgrind_annotate --auto=no --threshold=100 "$out/rust.callgrind"
callgrind_annotate --auto=no --inclusive=yes --tree=caller --threshold=100 \
  "$out/rust.callgrind"
```

The continuation collected eager N=3 and trace N=1/N=3 for LM3, eager/trace
N=3 for batched matmul, and eager N=3 for matmul. Matching N=1 profiles were
reused from the previous directory and reannotated with threshold **100**.
`TENFERRO_ANALYZE_PATH=1` was used only for LM3. Previous elementwise N=1/N=3
profiles are reused. Divide Rust LM differences by **4**, not 2, because the
runner executes both distinct stored paths. Average the two PyTorch LM windows.

## Derived checks

```bash
python3 "$helpers/summarize.py"
```

This reads the retained 100%-threshold SELF annotations and updates
`summary.json`; it asserts shared Rust multiply and batched GEMM kernel counts.
Do not substitute inclusive call trees or a truncated 95% annotation.

`mul-symbols.txt` and `mul-disassembly.txt` retain the Rust AVX2 kernel;
`pytorch-mul-symbols.txt` and `pytorch-mul-disassembly.txt` retain the PyTorch
AVX2 kernel. Addresses are specific to the recorded binaries. Re-find symbols
with `nm -S -C` before using `objdump` after rebuilding.

Copy/map summary categories select named strided identity-copy and PyTorch
direct-copy kernel self-costs; they are not a complete measure of memory traffic.
All-zero output/shape checks happen after PyTorch instrumentation stops; they
are smoke tests, not nonzero numerical correctness proofs.
