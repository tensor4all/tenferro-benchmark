"""Summarize 100%-threshold SELF-cost annotations, not inclusive call trees."""
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
old = root.with_name("openblas-instructions")


def read(name):
    text = Path(name).read_text()
    assert "Thresholds:       100" in text, name
    rows = [(int(m[1].replace(",", "")), m[2]) for m in re.finditer(
        r"^\s*([\d,]+)\s+\([^\n]*?%\)\s+(.+)$", text, re.M)]
    def count(predicate):
        return sum(n for n, symbol in rows if predicate(symbol))
    return {
        "total": count(lambda s: s == "PROGRAM TOTALS"),
        "gemm_kernel": count(lambda s: "dgemm_kernel" in s),
        "memset": count(lambda s: "__memset" in s),
        "copy_map": count(lambda s: "typed_copy_into_uninit" in s or
                          ("strided_basic::map_view::" in s and
                           "MaybeUninit<f64>" in s and "Identity" in s) or
                          "direct_copy_kernel" in s),
        "mul_kernel": count(lambda s: "simd_mul_f64_into::Mul" in s or
                            ("callback_fn" in s and "mul_kernel" in s)),
    }


def delta(a, b, divisor):
    return {k: (b[k] - a[k]) / divisor for k in a}


result = {}
for case in ("mul", "bmm", "mm", "lm3"):
    for mode in ("eager", "trace"):
        if case == "mm" and mode == "trace":
            continue
        base = old if case == "mul" else root
        a = read(base / f"{case}-{mode}-n1-annotated.txt")
        b = read(base / f"{case}-{mode}-n3-annotated.txt")
        # LM runs BOTH distinct paths: two additional runs per path = four.
        result[f"{case}_{mode}"] = delta(a, b, 4 if case == "lm3" else 2)
for case in ("mul", "bmm"):
    a = read(root / f"{case}-pytorch-window-n1-annotated.txt")
    b = read(root / f"{case}-pytorch-window-n3-annotated.txt")
    result[f"{case}_pytorch"] = delta(a, b, 2)
result["mm_pytorch"] = read(root / "mm-pytorch-window-n1-annotated.txt")
a = read(root / "lm3-pytorch-opt_flops-window-n1-annotated.txt")
b = read(root / "lm3-pytorch-opt_size-window-n1-annotated.txt")
result["lm3_pytorch"] = {k: (a[k] + b[k]) / 2 for k in a}
assert result["mul_eager"]["mul_kernel"] == result["mul_trace"]["mul_kernel"] == 34603035
assert result["mul_pytorch"]["mul_kernel"] == 4718656
assert result["bmm_eager"]["gemm_kernel"] == result["bmm_trace"]["gemm_kernel"]
(root / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
