"""Callgrind-only warmed opt_einsum window; run from the benchmark repo root.

Usage: valgrind --tool=callgrind --instr-atstart=no ... python FILE CASE COUNT [STRATEGY]
The explicit window is written to the Callgrind output with suffix .1.
Input/layout/path construction and one warmup are outside the profile.
The loop includes output release, as in the Rust N=3 minus N=1 differential.
"""
import ctypes
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd() / "scripts"))
import benchmark_python as bench

bench.configure_thread_env(1)
torch = bench.configure_pytorch_threads(1)
import opt_einsum as oe

case, count = sys.argv[1], int(sys.argv[2])
strategy = sys.argv[3] if len(sys.argv) > 3 else "opt_flops"
instance, = bench.load_instances(case)
assert instance.get("dtype", "float64") == "float64"
operands = [torch.zeros(shape, dtype=torch.float64) for shape in instance["shapes"]]
expression = oe.contract_expression(
    bench.get_format_string(instance), *instance["shapes"],
    optimize=bench.path_to_opt_einsum(instance["paths"][strategy]["path"]),
)
expected_shape = tuple(expression(*operands, backend="torch").shape)
blas = ctypes.CDLL("/opt/openblas/lib/libopenblas.so.0")
assert torch.get_num_threads() == torch.get_num_interop_threads() == 1
assert blas.openblas_get_num_threads() == 1
window = ctypes.CDLL(str(Path(__file__).with_name("callgrind_window.so").resolve()))
window.profile_start.restype = window.profile_stop.restype = None
assert window.under_valgrind() > 0
assert count > 0
print(json.dumps({"case": case, "count": count, "strategy": strategy,
                  "torch": torch.__version__, "torch_threads": torch.get_num_threads(),
                  "interop_threads": torch.get_num_interop_threads(),
                  "blas_threads": blas.openblas_get_num_threads(),
                  "output_shape": expected_shape}), flush=True)
window.profile_start()
for _ in range(count):
    output = expression(*operands, backend="torch")
    del output
window.profile_stop()
# Outside the counted window: basic output validation, not a nonzero-value oracle.
output = expression(*operands, backend="torch")
assert tuple(output.shape) == expected_shape and torch.count_nonzero(output).item() == 0
