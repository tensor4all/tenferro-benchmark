#!/usr/bin/env bash
# Run inside tenferro-openblas-analysis, from the benchmark checkout root.
# These are instrumented instruction profiles, NOT native timing results.
set -euo pipefail
source scripts/thread_env.sh
configure_cpu_thread_env 1
out="${1:-data/results/amd-cpu/diagnostics/openblas-instructions/reproduction-$(date +%Y%m%d_%H%M%S)}"
mkdir -p "$out"
export BENCH_WARMUPS=1
while read -r instance mode runs label; do
    unset TENFERRO_ANALYZE_PATH
    if [[ "$instance" == lm_batch_likelihood_sentence_3_12d ]]; then
        export TENFERRO_ANALYZE_PATH=1
    fi
    BENCH_INSTANCE="$instance" TENFERRO_MODE="$mode" BENCH_RUNS="$runs" \
      valgrind --tool=callgrind \
      --callgrind-out-file="$out/$label.callgrind" \
      target/release/tenferro-einsum-benchmark > "$out/$label.log" 2>&1
    callgrind_annotate --auto=no --threshold=100 "$out/$label.callgrind" \
      > "$out/$label-annotated.txt"
    callgrind_annotate --auto=no --inclusive=yes --tree=caller --threshold=99 \
      "$out/$label.callgrind" > "$out/$label-callers.txt"
done <<'CASES'
bin_elementwise_mul_2048x2048 eager 1 mul-eager-full
bin_elementwise_mul_2048x2048 trace 1 mul-trace-full
bin_elementwise_mul_2048x2048 eager 3 mul-eager-n3
bin_elementwise_mul_2048x2048 trace 3 mul-trace-n3
bin_batched_matmul_b32_m128_n128_k128 eager 1 bmm-eager-full
bin_batched_matmul_b32_m128_n128_k128 trace 1 bmm-trace-full
bin_matmul_1024 eager 1 mm-eager-full
lm_batch_likelihood_sentence_3_12d eager 1 lm3-eager-full
CASES
