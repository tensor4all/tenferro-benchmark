#define _GNU_SOURCE
#include <dlfcn.h>
#include <time.h>
#include <stdio.h>
#include <stdint.h>
static uint64_t calls[4], nanos[4];
static uint64_t now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return (uint64_t)t.tv_sec*1000000000+t.tv_nsec; }
void dgeqrf_(int*m,int*n,double*a,int*lda,double*tau,double*w,int*lw,int*info) {
 static void(*f)(int*,int*,double*,int*,double*,double*,int*,int*);
 if(!f) f=dlsym(RTLD_NEXT,"dgeqrf_");
 int k=*lw==-1?0:1; uint64_t t=now(); f(m,n,a,lda,tau,w,lw,info); nanos[k]+=now()-t; calls[k]++;
}
void dorgqr_(int*m,int*n,int*k,double*a,int*lda,double*tau,double*w,int*lw,int*info) {
 static void(*f)(int*,int*,int*,double*,int*,double*,double*,int*,int*);
 if(!f) f=dlsym(RTLD_NEXT,"dorgqr_");
 int j=*lw==-1?2:3; uint64_t t=now(); f(m,n,k,a,lda,tau,w,lw,info); nanos[j]+=now()-t; calls[j]++;
}
__attribute__((destructor)) static void report(void) {
 for(int i=0;i<4;i++) fprintf(stderr,"LAPACK_PROBE %d calls=%lu ns=%lu avg_ns=%.1f\n",i,calls[i],nanos[i],calls[i]?(double)nanos[i]/calls[i]:0);
}
