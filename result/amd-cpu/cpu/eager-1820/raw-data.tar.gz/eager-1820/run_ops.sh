#!/usr/bin/env bash
set -euo pipefail
cd /home/shinaoka/tensor4all/.worktrees/bench-cpu-eager-1820
threads=${1:-1}
label=${2:-baseline}
cores=${3:-1}
export LD_LIBRARY_PATH="$MKLROOT/lib:${LD_LIBRARY_PATH:-}"
source scripts/thread_env.sh
configure_cpu_thread_env "$threads"
export MKL_DYNAMIC=FALSE PUBLICATION_GATE_PROFILE=full PUBLICATION_GATE_TENFERRO_MODE=eager
export BENCH_RUNS=15 BENCH_WARMUPS=3
out="$PWD/data/results/amd-cpu/cpu/eager-1820/${label}-t${threads}"
mkdir -p "$out"
export CPU_OPS_RAW_SAMPLES="$out/samples.jsonl"
taskset -c "$cores" target/release/publication_gate > "$out/tenferro.csv" 2> "$out/tenferro.stderr"
taskset -c "$cores" .venv/bin/python scripts/benchmark_cpu_ops_python.py --backend pytorch-cpu --num-threads "$threads" --output "$out/torch.csv" > "$out/torch.log" 2>&1
